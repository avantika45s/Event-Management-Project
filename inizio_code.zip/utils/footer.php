<hr class = "footerline"><!--css modified horizontal line-->
<footer>
    <div class = "container">
        <div class = "row">
            <section>
                <div class = "footerContent col-md-4"><!--left content-->
                    <p class = "footerContent1">
                        <strong>I</strong><span class = "small footerSubtext">nizio</span>
                        
                    </p>

                    <p class = "footerSubtext2">
                        Indian Institue of Information Technology, Allahabad<br>
                        &copy; Inizio
                        <ul list-style-type='none'>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Terms of Service</a></li>
                <li><a href="./contact.php">Contact Us</a></li>
            </ul>
                    </p>
                </div>
            </section>
            <section>
                <div class = "footcontent col-md-4"><!--middle content-->
                    DL824 Multimedia Design/Web Engineering<br>
                    Creative Computing 2024.<br>
                    Julz Engracio, N00145647
                </div>
            </section>
            <section>
                <div class = "footcontent col-md-4"><!--right content-->
                    Follow Us:<br>
                        <img src = "images/facebook.png">
                        <img src = "images/twitter.png">
                        <img src = "images/googleplus.png">
                        <img src = "images/youtube.png">
                </div>
            </section>
        </div>
    </div>
</footer>